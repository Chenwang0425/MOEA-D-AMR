function [L_pro,P_pro,Q_pro] = IdentifyPromisingPoint(L,Population)

    d_min = min(pdist(L));

    %% Normalize Population
    [~, m] = size(L);
    norP_F = normalize(Population.objs,1,'range');
    Q = norP_F - repmat(sum(norP_F, 2)/m,1,m);

    %% Obtain the promising reference points
    distance_L_to_Q = pdist2(L,Q);
    A = sort(distance_L_to_Q,2);
    promising_index = find(A(:,1)<=0.5*d_min);
    L_pro = L(promising_index,:);
    P_pro = Population(promising_index);
    Q_pro = Q(promising_index,:);
end

