function EP = UpdateExternalPopulation(EP,Offsprings,nEP)
% Update the external population

    %% Select the non-dominated solutions
    EP = [EP,Offsprings];
    EP = EP(NDSort(EP.objs,1)==1);
    [N,M] = size(EP.objs);
	
    %% Delete the overcrowded solutions
    Dis = pdist2(EP.objs,EP.objs);
    Dis(logical(eye(length(Dis)))) = inf;
    Del = false(1,N);
    while sum(Del) < N-nEP
        Remain = find(~Del);
        subDis = sort(Dis(Remain,Remain),2);
        [~,worst] = min(prod(subDis(:,1:min(M,length(Remain))),2));
        Del(Remain(worst)) = true;
    end   
    EP = EP(~Del);
end