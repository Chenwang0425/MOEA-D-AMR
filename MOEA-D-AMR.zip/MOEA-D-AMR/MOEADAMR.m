classdef MOEADAMR < ALGORITHM
% <multi/many> <real>

%------------------------------- Reference --------------------------------
% Wang Chen, Jian Chen, Liping Tang, Xinmin Yang, Hui Li, A decomposition-based 
% evolutionary algorithm with multiple reference points strategy for multiobjective 
% optimization.

%------------------------------- Copyright --------------------------------
% Copyright (c) 2022 BIMK Group. You are free to use the PlatEMO for
% research purposes. All publications which use this platform or any code
% in the platform should acknowledge the use of "PlatEMO" and reference "Ye
% Tian, Ran Cheng, Xingyi Zhang, and Yaochu Jin, PlatEMO: A MATLAB platform
% for evolutionary multi-objective optimization [educational forum], IEEE
% Computational Intelligence Magazine, 2017, 12(4): 73-87".
%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            
            %% Parameter setting
            [delta1,nr,epsilon] = Algorithm.ParameterSet(0.9,2,0.8);
            if Problem.M <= 3
                delta2 = 0.9;
            else
                delta2 = 1;
            end

            %% Generate the reference points
 	        [L,Problem.N] = URS(Problem.N, Problem.M);
            T = ceil(Problem.N/10);

            % Size of external elite
            nEP = ceil(Problem.N * 1.5);
            
            %% Detect the neighbours of each solution
            B = pdist2(L, L);
            [~,B] = sort(B, 2);
            B = B(:, 1:T);

            %% Generate random population
            Population = Problem.Initialization();
            Z = min(Population.objs,[],1);

            %% Optimization
            EP = [];
            while Algorithm.NotTerminated(Population)
                
                % For each solution
                Offsprings(1:Problem.N) = SOLUTION();
                for i = 1 : Problem.N
                    % Choose the parents
                    if rand < delta1
                        V1 = B(i,randperm(end));
                    else
                        V1 = randperm(Problem.N);
                    end

                   % Generate an offspring
                   Offsprings(i) = OperatorGAhalf(Population(V1(1:2)));
%                    Offsprings(i) = OperatorDE(Population(i),Population(V1(1)),Population(V1(2)));
                    
                   Z = min(Z,Offsprings(i).obj);
                   MergeP = [Population,Offsprings(i)];
                   if ceil(Problem.FE/Problem.N) <= 10
                       Zmax = max(MergeP.objs,[],1);
                   else
                       Zmax = max(MergeP(NDSort(MergeP.objs,1)==1).objs,[],1);
                   end

                    % Associate the nearst subproblem for Offsprings(i)
                    Offspring_Nor = (Offsprings(i).obj - Z) ./ (Zmax - Z);
                    Offspring_Nor = Offspring_Nor - sum(Offspring_Nor) / Problem.M;
                    [~,rank] = sort(pdist2(Offspring_Nor,L),'ascend');%
                    index = rank(1);
                    
                    if rand < delta2
                        V2 = B(index,randperm(end));
                    else
                        V2 = randperm(Problem.N);
                    end
                   
                    % Update the solutions in V2 by PS approach
                    g_old = max(abs(Population(V2).objs-repmat(Z,length(V2),1))./repmat(Zmax-Z,length(V2),1)-L(V2,:),[],2);
                    g_new = max(repmat(abs(Offsprings(i).obj-Z)./(Zmax-Z),length(V2),1) - L(V2,:),[],2);
                    Population(V2(find(g_old>=g_new,nr))) = Offsprings(i);
                end
                        
                % Update external population
                if ceil(Problem.FE/Problem.N) < epsilon * ceil(Problem.maxFE/Problem.N)
                    if isempty(EP)
                        EP = UpdateExternalPopulation(Population,Offsprings,nEP);
                    else
                        EP = UpdateExternalPopulation(EP,Offsprings,nEP);
                    end
                end
                
                % Update reference points
                if ceil(Problem.FE/Problem.N) == epsilon * ceil(Problem.maxFE/Problem.N)
                    [L_pro,P_pro,Q_pro] = IdentifyPromisingPoint(L, Population);
                    if size(L_pro,1) < Problem.N
                        [L,Population] = UpdateReferencePoint(EP,L_pro,P_pro,Q_pro);
                        B = pdist2(L, L);
                        [~,B] = sort(B, 2);
                        B = B(:, 1:T);
                    end
                end

            end
        end
    end
end