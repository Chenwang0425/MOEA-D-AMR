function [L,P]= UpdateReferencePoint(EP,L_pro,P_pro,Q_pro) 
    
    %% Update L using the combination EP and L_pro
    [~,m] = size(L_pro);
    nor_EP = normalize(EP.objs,1,'range');
    S = nor_EP-repmat(sum(nor_EP,2)/m,1,m);
    com_ = [S;L_pro];
    [N, M] = size(com_);
    Dis = pdist2(com_,com_);
    Dis(logical(eye(length(Dis)))) = inf;
    Del = false(1,N);
    while sum(Del) < N-length(EP)/1.5
        Remain = find(~Del);
        subDis = sort(Dis(Remain,Remain),2);
        [~,worst] = min(prod(subDis(:,1:min(M,length(Remain))),2));
        Del(Remain(worst)) = true;
    end   
    L = com_(~Del,:);

    %% Match solutions for subproblems
    ScupQ = [S;Q_pro];
    com_Population = [EP,P_pro];
    Dis = pdist2(L,ScupQ);
    [~,indices] = min(Dis,[],2);
    P = com_Population(indices);
    
end


