function [L,N] = URS(N,M)

    L1 = lhsdesign(20000, M, 'criterion', 'maximin'); 
    L1 = L1-repmat(sum(L1,2)/M,1,M);
    
    n = 2^M;
    L = (dec2bin(0:n-1)-'0')-repmat(sum(dec2bin(0:n-1)-'0',2)/M,1,M);
    L_lb = min(L); 
    L_ub = max(L);
    all_rows = true(size(L,1),1);
    unvalid_rows = all(L>L_lb & L<L_ub,2);
    all_rows(unvalid_rows) = false; 
    L = L(all_rows,:);
    
    while size(L,1) < N
        index = find_index_with_largest_distance (L,L1);
        L(size(L,1)+1,:)=L1(index,:);
        L1(index,:)=[];
    end	
end

function index = find_index_with_largest_distance (L1,L2)
    Distance = pdist2(L2,L1);
    Temp     = sort(Distance,2);
    [~,Rank] = sortrows(Temp);
    index=Rank(length(Rank));
end